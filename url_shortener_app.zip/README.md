# URL Shortener App

A minimal, secure URL shortener web application with admin dashboard, click analytics, and multi-language support (English/Arabic).

## 🔧 Features
- URL shortening with 6-character codes
- Admin login system (Flask sessions)
- Click tracking per short URL
- Multi-language UI: English and Arabic (RTL support)
- Responsive interface with Bootstrap 5

## 🧪 Admin Credentials
```
Email: fnew78956@gmail.com
Password: Moore555$
```

## 🚀 Getting Started

### 1. Clone the repo and navigate into it
```bash
git clone https://github.com/your-username/url-shortener.git
cd url-shortener
```

### 2. Create virtual environment and install dependencies
```bash
python3 -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate
pip install flask flask_sqlalchemy werkzeug
```

### 3. Run the app
```bash
python app.py
```

### 4. Open in browser
Visit: [http://localhost:5000](http://localhost:5000)

## 🌐 Deployment
You can deploy this app using:
- **Render.com** (free web hosting)
- **Heroku** (deprecated free tier, still usable)
- **Replit** (web IDE)

Ensure to set environment variables:
```
SECRET_KEY=your_secret_here
```

## 📁 Project Structure
- app.py           # Main Flask app
- templates/       # HTML templates
  - base.html
  - login.html
  - dashboard.html
- shortener.db     # SQLite DB (auto-created)
- README.md        # This file

---

Enjoy your URL shortener!
